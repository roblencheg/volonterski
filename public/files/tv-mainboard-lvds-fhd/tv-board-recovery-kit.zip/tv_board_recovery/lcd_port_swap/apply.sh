#!/system/bin/sh
set -eu
BASE=/data/local/tmp/lcd_port_swap
KEY=/sys/class/unifykeys
ORIGINAL_SHA=1590b7e451002e2aa8b0aa4d9e248732024c317ec332771f2df2c7c642ad8509
FHD_SHA=b79830f763a92d1b1647921b4e1dab164a94570d7833d46e2537b91756da2ab3
fail() { echo "ERROR: $*" >&2; exit 1; }
hash_file() { sha256sum "$1" | cut -d ' ' -f 1; }
[ "$(id -u)" = 0 ] || fail "root required"
[ "$(hash_file "$BASE/lcd_original.bin")" = "$ORIGINAL_SHA" ] || fail "original file hash mismatch"
[ "$(hash_file "$BASE/lcd_fhd.bin")" = "$FHD_SHA" ] || fail "FHD file hash mismatch"
INI=/mnt/vendor/param/panel/panel_customer.ini
INI_ORIGINAL_SHA=527a219e8abf4883632528c1d0aa5c6f59ae6aadf24c15c44f9371a4c6182834
INI_FHD_SHA=339e6d93bde23069fe5d181927cdded2265491099c8fc500bf1585699a077fb1
[ "$(hash_file "$BASE/panel_customer_original.ini")" = "$INI_ORIGINAL_SHA" ] || fail "backup INI hash mismatch"
[ "$(hash_file "$BASE/panel_customer_fhd.ini")" = "$INI_FHD_SHA" ] || fail "FHD INI hash mismatch"
select_lcd() {
    dd if="$BASE/key_name.txt" of="$KEY/name" bs=4 count=1
    [ "$(cat "$KEY/name")" = lcd ] || fail "wrong selected key"
    [ "$(cat "$KEY/size")" = 145 ] || fail "wrong key size"
}
select_lcd
dd if="$KEY/read" of="$BASE/lcd_before_profile.bin" bs=4096 count=1
BEFORE_KEY_SHA=$(hash_file "$BASE/lcd_before_profile.bin")
BEFORE_INI_SHA=$(hash_file "$INI")
echo "CURRENT_LCD_SHA=$BEFORE_KEY_SHA"
echo "CURRENT_INI_SHA=$BEFORE_INI_SHA"
case "$BEFORE_KEY_SHA" in "$ORIGINAL_SHA"|"$FHD_SHA") ;; *) fail "unknown current LCD key; nothing changed" ;; esac
case "$BEFORE_INI_SHA" in "$INI_ORIGINAL_SHA"|"$INI_FHD_SHA") ;; *) fail "unknown current INI; nothing changed" ;; esac
cp "$INI" "$BASE/panel_before_profile.ini"
MUTATED=0
rollback_on_failure() {
    if [ "$MUTATED" = 1 ]; then
        trap - EXIT
        set +e
        echo "ERROR: restoring state from before this script"
        cp "$BASE/panel_before_profile.ini" "$INI"
        dd if="$BASE/key_name.txt" of="$KEY/name" bs=4 count=1
        dd if="$BASE/lcd_before_profile.bin" of="$KEY/write" bs=145 count=1
        dd if="$KEY/read" of="$BASE/lcd_rollback_readback.bin" bs=4096 count=1
        if [ "$(hash_file "$INI")" = "$BEFORE_INI_SHA" ] && [ "$(hash_file "$BASE/lcd_rollback_readback.bin")" = "$BEFORE_KEY_SHA" ]; then
            echo "PREVIOUS_STATE_RESTORED_VERIFIED"
        else
            echo "ROLLBACK_VERIFICATION_FAILED"
        fi
        echo "DO NOT REBOOT; save all output"
        exit 1
    fi
}
trap rollback_on_failure EXIT
MUTATED=1
cp "$BASE/panel_customer_fhd.ini" "$INI"
[ "$(hash_file "$INI")" = "$INI_FHD_SHA" ] || fail "INI readback mismatch"
select_lcd
dd if="$BASE/lcd_fhd.bin" of="$KEY/write" bs=145 count=1
dd if="$KEY/read" of="$BASE/lcd_profile_readback.bin" bs=4096 count=1
[ "$(hash_file "$BASE/lcd_profile_readback.bin")" = "$FHD_SHA" ] || fail "LCD readback mismatch"
sync
MUTATED=0
trap - EXIT
echo "LCD_PORT_SWAP_WRITE_VERIFIED"
echo "INI_SHA=$INI_FHD_SHA"
echo "LCD_SHA=$FHD_SHA"
echo "No backlight key, bootloader or U-Boot environment changes."
echo "Reboot is NOT automatic."

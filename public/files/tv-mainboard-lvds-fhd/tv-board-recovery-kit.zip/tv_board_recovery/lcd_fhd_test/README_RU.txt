Профиль конкретного ремонта TP.T950ST.PB752(N). Начните с ../INSTRUCTION_RU.html.
Применение: apply_profile_fhd.sh. Откат: restore_profile.sh.
Промежуточный профиль Full HD имеет port_swap=0; исправление A/B находится в ../lcd_port_swap.
Не применять к другой панели или обходить проверки хешей.
